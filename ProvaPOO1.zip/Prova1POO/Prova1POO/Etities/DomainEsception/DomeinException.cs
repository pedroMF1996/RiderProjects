using System;

namespace Prova1POO.Etities.DomainEsception
{
    public class DomeinException: ApplicationException
    {
        public DomeinException(string msg):base(msg)
        {
            
        }
    }
}